repo: pippopippante/wilditaly
branch: main

## Last sync
date: 2026-09-27T11:55:50Z

### Updated in this project
- Home riprogettata, con la sezione "scaffale per scaffale" rifatta da capo
- Foto di categorie e prodotti copiate da assets/img/

## Screen map
| Screen | Repo files |
|---|---|
| Home.dc.html | index.html, assets/css/wild.css, assets/js/wild.js (mountHome, prodCard, headerHtml), assets/js/catalogo.js |
