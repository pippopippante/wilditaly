repo: pippopippante/wilditaly
branch: main

## Last sync
date: 2026-09-26T21:53:28Z

### Updated in this project
- Scheda prodotto v2: versione telefono dedicata, basata sulla schermata 2b del sito
- Scheda prodotto v2: desktop con galleria + colonna d'acquisto ferma

## Screen map
| Screen | Repo files |
|---|---|
| Scheda prodotto v2.dc.html (desktop) | prodotto.html, assets/js/wild.js, assets/js/catalogo.js, assets/css/wild.css |
| Scheda prodotto v2.dc.html (telefono) | design/Wild Italy.dc.html (2b), assets/css/wild.css (buybar, hdr__ctx, crumbs mobile) |
| Scheda prodotto.dc.html | prodotto.html, assets/js/wild.js, assets/css/wild.css |
