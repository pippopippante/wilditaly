repo: pippopippante/wilditaly
branch: main

## Last sync
date: 2026-09-27T15:11:11Z
### Updated in this project
- Pagina categoria: Categoria.dc.html (v1), Categoria v2.dc.html (desktop), Categoria mobile.dc.html + tavola

## Screen map
| Screen | Files |
|---|---|
| Categoria (desktop e mobile) | categoria.html, assets/js/wild.js (mountCategoria, prodCard, header, tabbar), assets/js/catalogo.js, assets/css/wild.css |
| Altri scaffali (titolo) | index.html (sezione «La bottega, scaffale per scaffale») |
